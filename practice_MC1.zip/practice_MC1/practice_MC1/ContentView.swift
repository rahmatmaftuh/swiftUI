//
//  ContentView.swift
//  practice_MC1
//
//  Created by Rahmat Maftuh Ihsan on 13/05/22.
//

import SwiftUI

struct ContentView: View {
    @State private var showModal = true

    var body: some View {
        VStack {
            Onboardingpage1()
        }
        
    }
    //ModalView(isShowing: $showModal)
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Onboardingpage1()
    }
}


