//
//  OnboardingPage2.swift
//  practice_MC1
//
//  Created by Rahmat Maftuh Ihsan on 15/05/22.
//

import SwiftUI

struct OnboardingPage2: View {
    @State private var isNext: Bool = false
    
    var body: some View {
        if isNext {
            OnboardingPage3()
        }else{
            ZStack{
                Image("Onboardingpage2")
                    .frame(maxHeight: .infinity, alignment: .bottom)
                    .ignoresSafeArea()
                
                Image("studying")
                    //.frame(maxHeight: .infinity, alignment: .top)
                    .position(x: 190, y: 150)
                VStack{
                    Spacer()
                        .frame(height:450)
                    Text("Maintain Focus During \nReading")
                        .font(.system(size:24, weight: .bold))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .frame(width: 300, height: 100)
                       
                        .ignoresSafeArea()
                    
                    Text("Readspace is an app that can help you maintain focus \nduring reading to better understand what you read by \ncreating reading sessions")
                        .font(.system(size:13))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .frame(width: 400, height: 50)
                        //.position(x: 190, y: 310)
                    
                        
                    Spacer()
                    
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.5)){
                            self.isNext = true
                        }
                    }, label:{
                        Text("Next".uppercased())
                    })
                    
                        .padding()
                        .frame(width: 346, height: 50)
                        
                        .background(Color.orange.cornerRadius(10))
                        .foregroundColor(.white)
                        .font(.headline)
                        //.position(x: 195, y: 200)
                    
                    //Ini cara biar naik ke atas gimana ya? kalau pake xy position, dia ga ditengah

                        
                }
                
            }
        }
        
        
    }
}

struct OnboardingPage2_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingPage2()
    }
}
