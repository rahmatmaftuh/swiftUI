//
//  LaunchScreenView.swift
//  practice_MC1
//
//  Created by Rahmat Maftuh Ihsan on 13/05/22.
//

import SwiftUI

struct LaunchScreenView: View {
    @State private var isActive = false
    @State private var size = 0.89
    @State private var opacity = 0.5
    
    var body: some View {
        if isActive {
            ContentView()
        } else{
        
            VStack{
                Image("vitamin")
                    .resizable()
                    .renderingMode(.original)
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 85, height: 85)
//                Text("Read Space")
//                 .font(Font.custom("SF Pro", size:26))
//                 .foregroundColor(.blue.opacity(0.80))
//            }
            //Animation
//            .scaleEffect(size)
//            .opacity(opacity)
//            .onAppear{
//                withAnimation(.easeIn(duration: 1.2)){
//                self.size = 0.9
//                self.opacity = 1.0
//                }
//            }
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1){
                    withAnimation(.easeInOut(duration: 0.5)) {
                        self.isActive = true
                    }
                   
                }
            }
            
        }
    }
}
struct LaunchScreenView_Previews: PreviewProvider {
    static var previews: some View {
        LaunchScreenView()
    }
}

