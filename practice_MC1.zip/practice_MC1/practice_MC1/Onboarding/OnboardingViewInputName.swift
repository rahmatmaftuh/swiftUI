//
//  OnboardingViewInputName.swift
//  practice_MC1
//
//  Created by Rahmat Maftuh Ihsan on 13/05/22.
//

import SwiftUI

struct OnboardingViewInputName: View {
    
    @State var userName: String = ""
    @State var dataArray: [String] = []
    
    var body: some View {
        ZStack{
            Image("HelloPage4")
                //.frame(maxHeight: .infinity, alignment: .top)
                .position(x: 190, y: 150)
            
            Image("Onboardingpage4")
                .frame(maxHeight: .infinity, alignment: .bottom)
                .ignoresSafeArea()
            
            VStack{
                Spacer()
                    .frame(height:500)
                Text("What is your name?")
                    .font(.system(size:24, weight: .bold))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                    //.frame(width: 300, height: 100)
                    //.position(x: 190, y: 550)
                    .ignoresSafeArea()
            
                
                TextField("Name", text: $userName)
                        
                    .foregroundColor(.white)
                    .padding()
                    .frame(width:346)
                    //.background(Color.white.opacity(0)).cornerRadius(10)
                    //.colorInvert()
                    
                    .font(.headline)
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white,lineWidth:1))
                    //position(x: 190, y: 300)
                
                Spacer()
                Button(action: {
                    if textIsAppropriate(){
                        saveText()
                    }
                    
                }, label:{
                    Text("Next".uppercased())
                    .padding()
                    .frame(width: 346, height: 50)
                    //.background(Color.orange.cornerRadius(10))
                    .background(textIsAppropriate() ? Color.orange : Color.gray.opacity(0.8))
                    
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .font(.headline)
                    //.position(x: 195, y: 200)
                })
                
                    .disabled(!textIsAppropriate())
                ForEach (dataArray, id: \.self){ data in
                    Text(data)
                }
                
        }
        }
        
        //cEK DISINI TUTORIALNYA https://www.youtube.com/watch?v=-_-BNwUZrrc
    }
    func textIsAppropriate() -> Bool{
        //Check text
        if userName.count >= 1 {
            return true
        }
        return false
    }
    
    func saveText(){
        dataArray.append(userName)
        userName = ""
        
        
    }
}

struct OnboardingViewInputName_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingViewInputName()
    }
}
