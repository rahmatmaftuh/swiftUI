//
//  OnboardingPage3.swift
//  practice_MC1
//
//  Created by Rahmat Maftuh Ihsan on 15/05/22.
//

import SwiftUI

struct OnboardingPage3: View {
    @State private var isNext: Bool = false
    
    var body: some View {
        if isNext {
            OnboardingViewInputName()
        }else{
            ZStack{
                Image("KumpulanNotes")
                    //.frame(maxHeight: .infinity, alignment: .top)
                    .position(x: 190, y: 150)
                
                Image("Onboardingpage3")
                    .frame(maxHeight: .infinity, alignment: .bottom)
                    .ignoresSafeArea()
                
                
                VStack{
                    Spacer()
                        .frame(height:500)
                    Text("Organize Your Library")
                        .font(.system(size:24, weight: .bold))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        //.frame(width: 300, height: 100)
                        //.position(x: 190, y: 550)
                        .ignoresSafeArea()
                    
                    Text("With Readspace, you can search, add, and organize books in your own library")
                        .font(.system(size:13))
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .frame(width: 300, height: 50)
                        //.position(x: 190, y: 290)
                    Spacer()
                    
                        
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.5)){
                            self.isNext = true
                        }
                    }, label:{
                        Text("Next".uppercased())
                    })
                        .padding()
                        .frame(width: 346, height: 50)
                        
                        .background(Color.orange.cornerRadius(10))
                        .foregroundColor(.white)
                        .font(.headline)
                        //.position(x: 195, y: 200)
                    //Ini cara biar naik ke atas gimana ya? kalau pake xy position, dia ga ditengah

                        
                }
                
            }
        }
        
    }
}

struct OnboardingPage3_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingPage3()
    }
}
