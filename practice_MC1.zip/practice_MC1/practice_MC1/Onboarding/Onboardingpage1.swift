//
//  Onboardingpage1.swift
//  practice_MC1
//
//  Created by Rahmat Maftuh Ihsan on 15/05/22.
//

import SwiftUI

struct Onboardingpage1: View {
    @State private var isNext: Bool = false
    var body: some View {
        if isNext {
            OnboardingPage2()
        }else{
            ZStack{
                Image("Onboardingpage1")
                    .frame(maxHeight: .infinity, alignment: .bottom)
                    .ignoresSafeArea()
                VStack {
                    Spacer()
                        .frame(height:30)
                    Image("vitamin")
                        .resizable()
                        .renderingMode(.original)
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 85, height: 85)
                    
                    Spacer()
                        .frame(height:70)
                    Text ("Welcome to")
                        .font(.system(size:24, weight: .semibold))
                        .foregroundColor(.blue.opacity(0.6))
                        .multilineTextAlignment(.center)
                        .padding(.top)
                    
                    
                    Text ("Readspace")
                        .font(.system(size:36, weight: .bold))
                        .foregroundColor(.blue.opacity(0.6))
                        .multilineTextAlignment(.center)
                    Spacer()
                    
                    VStack (spacing:30){
                        
                        HStack (spacing: 30){
                            Image("SafeSpace")
                                .resizable()
                                .scaledToFit()
                                .frame(width:57.64, height:50)
                            VStack(alignment: .leading){
                                Text ("Safe Space")
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(.white)
                                Text ("Read quietly,  free from digital distractions")
                                    .foregroundColor(.white)
                                    .frame(width: 220,alignment: .leading)
                                
                            }
                        }
                        
                        HStack (spacing: 30){
                            Image("TakeNotes")
                                .resizable()
                                .scaledToFit()
                                .frame(width:57.64, height:50)
                            VStack(alignment: .leading){
                                Text ("Take Notes")
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(.white)
                                Text ("Write down interesting findings from the text, then save, customize and share")
                                    .multilineTextAlignment(.leading)
                                    .foregroundColor(.white)
                                    .frame(width: 220,alignment: .leading)
                                
                                
                            }
                        }
                        HStack (spacing: 30){
                            Image("ReaderTracker")
                                .resizable()
                                .scaledToFit()
                                .frame(width:57.64, height:50)
                            
                            VStack(alignment: .leading){
                                Text ("Reading Track")
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(.white)
                                Text ("Help you complete the book in your own pace")
                                    .multilineTextAlignment(.leading)
                                    .foregroundColor(.white)
                                    .frame(width: 220,alignment: .leading)
                                
                            }
                        }
                    }
                    Spacer()
                        .frame(height: 50)
                    
                    VStack{
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.5)) {
                                self.isNext = true
                            }
                        }, label:{
                            Text("Next".uppercased())
                        })
                        
                            .padding()
                            .frame(width: 346, height: 50)
                            .background(Color.orange.cornerRadius(10))
                            .foregroundColor(.white)
                            .font(.headline)
                        
                        
                        
                    }
                    
                }
                
                
                
                
                
                
            }
        }
    }
}

struct Onboardingpage1_Previews: PreviewProvider {
    static var previews: some View {
        Onboardingpage1()
    }
}
