//
//  practice_MC1App.swift
//  practice_MC1
//
//  Created by Rahmat Maftuh Ihsan on 12/05/22.
//

import SwiftUI

@main
struct practice_MC1App: App {
    var body: some Scene {
        WindowGroup {
            LaunchScreenView()
        }
    }
}
