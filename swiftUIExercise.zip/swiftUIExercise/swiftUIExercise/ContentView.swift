//
//  ContentView.swift
//  swiftUIExercise
//
//  Created by Rahmat Maftuh Ihsan on 22/04/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            Image("Mountain")
                .resizable()
                .edgesIgnoringSafeArea(.all )
            VStack(spacing:30){
                Logo()
                formbox()
            }
            .padding(.all,200)
        }
//Belajar menulis nama
//        Text("Hello, Rahmat!").foregroundColor(Color.red).background(Color.green)
///    }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
            ContentView()
        }
    }
}

//imagenya mau dijadiin komponen sehingga
struct Logo : View{
    var body: some View {
        
        VStack{
            Image(systemName: "pencil.slash")
                .resizable() //Ini untuk nyesuain logo dengan kotak yang ada
                .frame(width: 100, height: 100)
                .background(Color.blue)
                .foregroundColor(Color.white)
                .padding()
                .background(Color.blue)
                .cornerRadius(20)
               
                
            Text ("Hello Swift UI").foregroundColor(Color.white)
        }
        
    }

}

struct formbox: View{
    @State var username : String = ""//ini untuk menampung data username
    @State var password : String = ""//ini untuk menampung data username
    var body: some View{
        VStack(alignment:.leading){//Rata kiri
            Text ("Username").font(.callout).bold()
            
            TextField("Username...", text:$username).textFieldStyle(RoundedBorderTextFieldStyle())
            
            Text ("Password").font(.callout).bold()
            
            TextField("Password...",text:$password).textFieldStyle(RoundedBorderTextFieldStyle())
            Button(action: {print("Hello Button")}){
                HStack{
                    Text("Sign in")
                    Spacer()
                }
            }
            .padding() //Jarak atas bawah biar pas
            .background(Color.black)
            .cornerRadius(10)
            .foregroundColor(Color.white)//biar tulisan sign in nya putih
        }
            .padding(.all,30)
            .background(Color.blue)
            .cornerRadius(10)
    }
}
