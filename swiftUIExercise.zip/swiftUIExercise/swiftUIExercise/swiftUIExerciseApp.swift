//
//  swiftUIExerciseApp.swift
//  swiftUIExercise
//
//  Created by Rahmat Maftuh Ihsan on 22/04/22.
//

import SwiftUI

@main
struct swiftUIExerciseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
