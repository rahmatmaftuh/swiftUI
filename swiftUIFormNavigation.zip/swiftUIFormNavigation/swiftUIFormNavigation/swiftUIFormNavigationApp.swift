//
//  swiftUIFormNavigationApp.swift
//  swiftUIFormNavigation
//
//  Created by Rahmat Maftuh Ihsan on 22/04/22.
//

import SwiftUI

@main
struct swiftUIFormNavigationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
