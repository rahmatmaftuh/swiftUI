//
//  ContentView.swift
//  swiftUIFormNavigation
//
//  Created by Rahmat Maftuh Ihsan on 22/04/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            Form{
                //Section foto profile
                Section(){
                    HStack{
                        NavigationLink(destination: About()){
                            Image("IMG_0384")
                                .resizable()
                                .frame(width: 50, height: 50)
                                .clipShape(Circle())//bentuk fotonya lingkaran
                            
                            //Nama dan status
                            VStack(alignment:.leading){
                                Text("Rahmat Maftuh").font(.headline)
                                Text("GRIT person").font(.caption)
                            }
                            
                        }
                        .padding(.top,10)
                        .padding(.bottom,10)
                    }
                }
                
                //section pengaturan
                Section(header: Text("Pengaturan")){
                    HStack(spacing:20){
                        NavigationLink(destination: About()){
                            Image(systemName: "star.fill")
                                .frame(width: 35, height: 35)
                                .background(Color.yellow)
                                .cornerRadius(10)
                                .foregroundColor(Color.white)
                            
                            Text("Pesan Berbintang")
                        }
                    }
                    
                    HStack(spacing:20){
                        NavigationLink(destination: About()){
                            Image(systemName: "tv")
                                .frame(width: 35, height: 35)
                                .background(Color.green)
                                .cornerRadius(10)
                                .foregroundColor(Color.white)
                            
                            Text("Whatsapp Web")
                        }
                    }
                    //section pengaturan akun
                    Section(header: Text("Pengaturan Akun")){
                        HStack(spacing:20){
                            NavigationLink(destination: About()){
                                Image(systemName: "person")
                                    .frame(width: 35, height: 35)
                                    .background(Color.blue)
                                    .cornerRadius(10)
                                    .foregroundColor(Color.white)
                                
                                Text("Akun")
                            }
                        }
                        HStack(spacing:20){
                            NavigationLink(destination: About()){
                                Image(systemName: "phone.circle")
                                    .frame(width: 35, height: 35)
                                    .background(Color.green)
                                    .cornerRadius(10)
                                    .foregroundColor(Color.white)
                                
                                Text("Chat")
                            }
                        }
                    }
                    
                }.navigationBarTitle("Setting")
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct About:View{
    var body: some View{
        Text("Halaman About")
    }
}
