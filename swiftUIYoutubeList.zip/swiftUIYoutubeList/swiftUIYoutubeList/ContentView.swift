//
//  ContentView.swift
//  swiftUIYoutubeList
//
//  Created by Rahmat Maftuh Ihsan on 22/04/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            TabView{
                Home()
                    .tabItem{
                        Image(systemName: "house.fill")
                        Text("Beranda")
                    }
                Home()
                    .tabItem{
                        Image(systemName: "paperplane.fill")
                        Text("Explore")
                    }
                Home()
                    .tabItem{
                        Image(systemName: "tray.fill")
                        Text("Subscription")
                    }
                Home()
                    .tabItem{
                        Image(systemName: "envelope.fill")
                        Text("Kotak Masuk")
                    }
                Home()
                    .tabItem{
                        Image(systemName: "play.rectangle.fill")
                        Text("Koleksi")
                    }
            }
            .accentColor(.red)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Home: View{
    var body: some View{
        NavigationView{
            Konten()
            
                .navigationBarItems(
                    leading:
                        HStack{
                            Button(action: {print ("Hello Button")}){
                                Image("Youtube")
                                    .renderingMode(.original)
                                    .resizable()
                                    .frame(width: 90, height: 60)
                                
                            }
                        },
                        trailing:
                        HStack(spacing:30){
                            Button(action: {print ("Hello Print")}){
                                Image(systemName: "tray.full")
                                    .foregroundColor(Color.secondary)
                            }
                            Button(action: {print ("Hello Print")}){
                                Image(systemName: "video.fill")
                                    .foregroundColor(Color.secondary)
                            }
                            Button(action: {print ("Hello Print")}){
                                Image(systemName: "magnifyingglass")
                                    .foregroundColor(Color.secondary)
                            }
                            Button(action: {print ("Hello Print")}){
                                Image("IMG_0384")
                                    .renderingMode(.original)
                                    .resizable()
                                    .frame(width: 20, height: 20)
                                    .clipShape(Circle())
                            }
                        }
                )
                .navigationBarTitle("", displayMode:.inline)
        }.navigationViewStyle(StackNavigationViewStyle())
    }
}

struct Konten: View{
    var body: some View{
        List{
            CellContent(imageContent: "content1", profileContent: "IMG_0384", judul: "How to make Aesthetic Stair", deskripsi: "This video about how to make aesthetic stair", durasi: "10:00")
            
            CellContent(imageContent: "content2", profileContent: "IMG_0384", judul: "How to make Aesthetic Stair", deskripsi: "This video about how to make aesthetic stair", durasi: "10:00")
            
            CellContent(imageContent: "content3", profileContent: "IMG_0384", judul: "How to make Aesthetic Stair", deskripsi: "This video about how to make aesthetic stair", durasi: "10:00")
        }
    }
}

//Komponen untuk cell
struct CellContent : View{
    var imageContent: String
    var profileContent: String
    var judul: String
    var deskripsi: String
    var durasi: String
    
    var body: some View{
        //Konten1
        VStack{
            ZStack(alignment: .bottomTrailing){
                Image (imageContent)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                Text (durasi)
                    .padding(.all, 5)
                    .foregroundColor(Color.white)
                    .font(.caption)
                    .background(Color.black)
                    .cornerRadius(5)
                    .padding(.trailing, 5)
                    .padding(.bottom, 5)
            }
            HStack(spacing:20){ //biar agak masuk
                Image (profileContent)
                    .resizable()
                    .frame(width: 30, height: 30)
                    .clipShape(Circle())
                
                VStack(alignment: .leading){//karena judulnya numpuk dengan deskripsi, jadinya pake vstack
                    Text (judul).font(.headline)
                    HStack{
                    Text (deskripsi).font(.caption)
                    }
                    
                }
                Spacer() //agar list bulletnya ada di pojok
                Image(systemName: "list.bullet")
            }
        }
    }
}





















//ALERT
//INI BACKUPAN CODE
//  ContentView.swift
//  swiftUIYoutubeList
//
//  Created by Rahmat Maftuh Ihsan on 22/04/22.
//

//import SwiftUI
//
//struct ContentView: View {
//    var body: some View {
//        ZStack{
//            TabView{
//                Home()
//                    .tabItem{
//                        Image(systemName: "house.fill")
//                        Text("Beranda")
//                    }
//                Home()
//                    .tabItem{
//                        Image(systemName: "paperplane.fill")
//                        Text("Explore")
//                    }
//                Home()
//                    .tabItem{
//                        Image(systemName: "tray.fill")
//                        Text("Subscription")
//                    }
//                Home()
//                    .tabItem{
//                        Image(systemName: "envelope.fill")
//                        Text("Kotak Masuk")
//                    }
//                Home()
//                    .tabItem{
//                        Image(systemName: "play.rectangle.fill")
//                        Text("Koleksi")
//                    }
//            }
//            .accentColor(.red)
//        }
//    }
//}
//
//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
//
//struct Home: View{
//    var body: some View{
//        NavigationView{
//            Konten()
//
//                .navigationBarItems(
//                    leading:
//                        HStack{
//                            Button(action: {print ("Hello Button")}){
//                                Image("Youtube")
//                                    .renderingMode(.original)
//                                    .resizable()
//                                    .frame(width: 90, height: 60)
//
//                            }
//                        },
//                        trailing:
//                        HStack(spacing:30){
//                            Button(action: {print ("Hello Print")}){
//                                Image(systemName: "tray.full")
//                                    .foregroundColor(Color.secondary)
//                            }
//                            Button(action: {print ("Hello Print")}){
//                                Image(systemName: "video.fill")
//                                    .foregroundColor(Color.secondary)
//                            }
//                            Button(action: {print ("Hello Print")}){
//                                Image(systemName: "magnifyingglass")
//                                    .foregroundColor(Color.secondary)
//                            }
//                            Button(action: {print ("Hello Print")}){
//                                Image("IMG_0384")
//                                    .renderingMode(.original)
//                                    .resizable()
//                                    .frame(width: 20, height: 20)
//                                    .clipShape(Circle())
//                            }
//                        }
//                )
//                .navigationBarTitle("", displayMode:.inline)
//        }.navigationViewStyle(StackNavigationViewStyle())
//    }
//}
//
//struct Konten: View{
//    var body: some View{
//        List{
//            //Konten1
//            VStack{
//                ZStack(alignment: .bottomTrailing){
//                    Image ("content1")
//                        .resizable()
//                        .aspectRatio(contentMode: .fill)
//                    Text ("10:00")
//                        .padding(.all, 5)
//                        .foregroundColor(Color.white)
//                        .font(.caption)
//                        .background(Color.black)
//                        .cornerRadius(5)
//                        .padding(.trailing, 5)
//                        .padding(.bottom, 5)
//                }
//                HStack(spacing:20){ //biar agak masuk
//                    Image ("IMG_0384")
//                        .resizable()
//                        .frame(width: 30, height: 30)
//                        .clipShape(Circle())
//
//                    VStack(alignment: .leading){//karena judulnya numpuk dengan deskripsi, jadinya pake vstack
//                        Text ("How to make Aesthetic Stair").font(.headline)
//                        HStack{
//                        Text ("Ini adalah deskripsi video kita - 300x ditonton - 9 jam yang lalu").font(.caption)
//                        }
//
//                    }
//                    Spacer() //agar list bulletnya ada di pojok
//                    Image(systemName: "list.bullet")
//                }
//            }
//            //Konten 2
//            VStack{
//                ZStack(alignment: .bottomTrailing){
//                    Image ("content2")
//                        .resizable()
//                        .aspectRatio(contentMode: .fill)
//                    Text ("10:00")
//                        .padding(.all, 5)
//                        .foregroundColor(Color.white)
//                        .font(.caption)
//                        .background(Color.black)
//                        .cornerRadius(5)
//                        .padding(.trailing, 5)
//                        .padding(.bottom, 5)
//                }
//                HStack(spacing:20){ //biar agak masuk
//                    Image ("IMG_0384")
//                        .resizable()
//                        .frame(width: 30, height: 30)
//                        .clipShape(Circle())
//
//                    VStack(alignment: .leading){//karena judulnya numpuk dengan deskripsi, jadinya pake vstack
//                        Text ("How to become").font(.headline)
//                        HStack{
//                        Text ("Ini adalah deskripsi video kita - 300x ditonton - 9 jam yang lalu").font(.caption)
//                        }
//
//                    }
//                    Spacer() //agar list bulletnya ada di pojok
//                    Image(systemName: "list.bullet")
//                }
//            }
//            //Konten3
//            VStack{
//                ZStack(alignment: .bottomTrailing){
//                    Image ("content3")
//                        .resizable()
//                        .aspectRatio(contentMode: .fill)
//                    Text ("10:00")
//                        .padding(.all, 5)
//                        .foregroundColor(Color.white)
//                        .font(.caption)
//                        .background(Color.black)
//                        .cornerRadius(5)
//                        .padding(.trailing, 5)
//                        .padding(.bottom, 5)
//                }
//                HStack(spacing:20){ //biar agak masuk
//                    Image ("IMG_0384")
//                        .resizable()
//                        .frame(width: 30, height: 30)
//                        .clipShape(Circle())
//
//                    VStack(alignment: .leading){//karena judulnya numpuk dengan deskripsi, jadinya pake vstack
//                        Text ("How to make Aesthetic Stair").font(.headline)
//                        HStack{
//                        Text ("Ini adalah deskripsi video kita - 300x ditonton - 9 jam yang lalu").font(.caption)
//                        }
//
//                    }
//                    Spacer() //agar list bulletnya ada di pojok
//                    Image(systemName: "list.bullet")
//                }
//            }
//        }
//    }
//}
//
