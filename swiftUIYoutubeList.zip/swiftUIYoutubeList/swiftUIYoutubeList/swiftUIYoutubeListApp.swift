//
//  swiftUIYoutubeListApp.swift
//  swiftUIYoutubeList
//
//  Created by Rahmat Maftuh Ihsan on 22/04/22.
//

import SwiftUI

@main
struct swiftUIYoutubeListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
